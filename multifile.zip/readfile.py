def readFile(name):
    with open(name) as f:
        return f.read()
